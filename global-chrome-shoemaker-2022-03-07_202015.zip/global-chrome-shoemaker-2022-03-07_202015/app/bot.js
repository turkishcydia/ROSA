const Discord = require('discord.js');
const db = require('quick.db');
const client = new Discord.Client({ disableMentions: 'everyone' });
const ayarlar = require('./ayarlar.json');
const fs = require('fs');
const moment = require('moment');
require('./util/eventLoader')(client);

var prefix = ayarlar.prefix;

const log = message => {
  console.log(`[${moment().format('YYYY-MM-DD HH:mm:ss')}] ${message}`);
};

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
fs.readdir("./komutlar/", (err, files) => {
  if (err) console.error(err);
  log(`${files.length} komut yüklenecek.`);
  files.forEach(f => {
    let props = require(`./komutlar/${f}`);
    log(`Yüklenen komut: ${props.help.name}.`);
    client.commands.set(props.help.name, props);
    props.conf.aliases.forEach(alias => {
      client.aliases.set(alias, props.help.name);
    });
  });
});
client.reload = command => {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./komutlar/${command}`)];
      let cmd = require(`./komutlar/${command}`);
      client.commands.delete(command);
      client.aliases.forEach((cmd, alias) => {
        if (cmd === command) client.aliases.delete(alias);
      });
      client.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        client.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};
client.load = command => {
  return new Promise((resolve, reject) => {
    try {
      let cmd = require(`./komutlar/${command}`);
      client.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        client.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};
client.unload = command => {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./komutlar/${command}`)];
      let cmd = require(`./komutlar/${command}`);
      client.commands.delete(command);
      client.aliases.forEach((cmd, alias) => {
        if (cmd === command) client.aliases.delete(alias);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

client.on('ready', () => {

  // Oynuyor Kısmı
  
      var actvs = [
        `${prefix}yardım ${client.guilds.cache.size} Sunucuyu`,
        `${prefix}yardım ${client.users.cache.size} Kullanıcıyı`, 
        `${prefix}yardım ${client.guilds.cache.size} Sunucuyu`,
        `${prefix}yardım`
    ];
    
    client.user.setActivity(actvs[Math.floor(Math.random() * (actvs.length - 1) + 1)], { type: 'LISTENING' });
    setInterval(() => {
        client.user.setActivity(actvs[Math.floor(Math.random() * (actvs.length - 1) + 1)], { type: 'LISTENING'});
    }, 15000);
    
  
      console.log ('_________________________________________');
      console.log (`Kullanıcı İsmi     : ${client.user.username}`);
      console.log (`Sunucular          : ${client.guilds.cache.size}`);
      console.log (`Kullanıcılar       : ${client.users.cache.size}`);
      console.log (`Prefix             : ${ayarlar.prefix}`);
      console.log (`Durum              : Bot Çevrimiçi!`);
      console.log ('_________________________________________');
    
    });



//-------------------- Selam sistemi Başlangıç--------------------//


//---Bu Kod main'e atılacaktır. 
//###CodeMareFi tarafından hazırlanmıştır - - - Ekleyen //###CMF

client.on('message', message => {
  // Data
  let sistem = db.fetch(`cmfsaas_${message.guild.id}`)

  // Sa
  var sa = ["Sa","SA","sa","Sea","sea","SEA","selamın aleyküm","Selamın Aleyküm","SELAMIN ALEYKÜm","selamun aleyküm","Selamun Aleyküm","SELAMUN ALEYKÜM", "Slm", "slm", "SLM", "Selamm", "Selam", "SELAM", "selam"]

  if(sistem === 'aktif'){
    if(sa.includes(message.content.toLowerCase())){
      message.channel.send(`${message.author} **meeoowwwwwww (Aleykümselam)**`)
    }
  } else {
    // Sistem Kapalıysa Bot İplemesin.
    return;
  }
})

  //-------------------- Selam sistemi Son--------------------//

client.on('message', message => {
    if (message.content.toLowerCase() === prefix + 'yenidenbaslat') {
    if (message.author.id !== `${ayarlar.sahip}`) {
      message.reply('Bu komudu sadece **Bot Sahibi** kullanabilir!');
    } else {
      message.channel.send(`Yeniden Başlıyorum`).then(msg => {
      console.log(`Yeniden başlıyorum..`);
      process.exit(0);
    })
   }
  }
})


client.on('message', msg => {
  if (msg.content.startsWith(prefix + "çekiliş")) {
    msg.reply(`Çekilişi Kazanan: ${msg.guild.members.random().displayName}`);
    }
    });

client.on('message', msg => {
  if (msg.content.startsWith(prefix + "şikayet")) {//sunucu kurucusuna yazdığınız mesajı gönderir.
    msg.reply("Şikayetiniz Kurucu'ya Bildirilmiştir")
    let mesaj = msg.content.substring(2 + 3);
    msg.delete();
    msg.guild.owner.send(`Şikayet Bildiren: **${msg.author.tag}** \nŞikayet: ` + mesaj);
    }
    });

client.on('message', message => {
if (message.content.toLowerCase() === prefix + "özlüsöz") {
    var sans = ["Affetmek geçmişi değiştirmez ama geIeceğin önünü açar","İnsanIar seninIe konuşmayı bıraktığında, arkandan konuşmaya başIarIar","Hayattan korkmayın çocuklar;iyi ve doğru bir şeyler yaptığınız zaman hayat öyle güzel ki","Mutluluğu tatmanın tek çaresi, onu paylaşmaktır.","Küçük şeylere gereğinden çok önem verenler, elinden büyük iş gelmeyenlerdir.","Bize yeni düşmanlar lazım. Eskileri hayranımız oldular.","Asla vazgeçmeyin, kaybedenler yalnızca vazgeçenlerdir.","10 kilitli kapıdan daha güvenlidir babanın evde oluşu.","Sevmek için “yürek” sürdürmek için “emek” gerek.","Bir insanın, bir insana verebileceği en güzel hediye; ona ayırabileceği zamandır."," Benim neden kardeşim yok baba  Seni görünce ikincisine cesaret edemedik.","Kendini Ne Kadar Büyük Görürsen Gör. Bende Sadece Gözümün Gördüğü Kadarsın. Ötesi yok.","Mutlu olmayı yarına bırakmak, karşıya geçmek için nehrin durmasını beklemeye benzer ve bilirsin, o nehir asla durmaz.– Grange"];
    var sonuc = sans[Math.floor((Math.random() * sans.length))];
    const embed = new Discord.MessageEmbed()
      .addField(`¡ ¡ ¡ ¡ ¡ `, `${sonuc}`)
      .setColor("RANDOM");
    return message.channel.send(embed);
}
});


client.on('message', msg => {
if (msg.content.toLowerCase() === prefix + "futbol") {
msg.channel.send(':soccer :soccer: :goal: :soccer')
.then(nmsg => nmsg.edit(':soccer: :goal: :soccer:'))
.then(nmsg => nmsg.edit(':soccer: :goal: :goal:'))
.then(nmsg => nmsg.edit(':soccer: :goal: :soccer:'))
.then(nmsg => nmsg.edit(':soccer: :goal:'))
.then(nmsg => nmsg.edit('**Güzel Maçtı Knk Bidaha Oynayalım :)**'));
}
});





client.elevation = message => {
  if (!message.guild) {
    return;
  }
  let permlvl = 0;
  if (message.member.hasPermission("BAN_MEMBERS")) permlvl = 2;
  if (message.member.hasPermission("ADMINISTRATOR")) permlvl = 3;
  if (message.author.id === ayarlar.sahip) permlvl = 4;
  return permlvl;
};

client.login(ayarlar.token);
