exports.conf = {
  aliases: [],
  permLevel: 0,
  kategori: 'Genel'
};
exports.help = {
  name: ' şikayet',
   description: 'Şikayetinizi Kurucuya bildirmenin pratik yolu.'
};