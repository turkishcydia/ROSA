exports.conf = {
  aliases: [],
  permLevel: 0,
  kategori: 'Eğlence'
};
exports.help = {
  name: ' özlüsöz',
   description: 'Rastgele özlü söz söylet.'
};